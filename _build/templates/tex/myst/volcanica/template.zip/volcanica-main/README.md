# Volcanica Journal

A port of the Volcanica Journal template with minimal modifications.

[](thumbnail.png)

- Author: Volcanica
- Author Website: https://jvolcanica.org/
- License: Unknown
- [Submission Guidelines](http://www.jvolcanica.org/ojs/index.php/volcanica/about/submissions)
