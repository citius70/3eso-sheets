# Changes made during port

The steps taken during the port were:

- removed `fontawesome` package from the style
